"use strict";
const electron = require("electron");
const path = require("path");
const utils = require("@electron-toolkit/utils");
const child_process = require("child_process");
const electronUpdater = require("electron-updater");
const icon = path.join(__dirname, "../../resources/icon.png");
let backendProcess = null;
electronUpdater.autoUpdater.autoDownload = false;
electronUpdater.autoUpdater.autoInstallOnAppQuit = true;
electronUpdater.autoUpdater.on("checking-for-update", () => {
  console.log("Checking for updates...");
});
electronUpdater.autoUpdater.on("update-available", (info) => {
  console.log("Update available:", info);
  electron.dialog.showMessageBox({
    type: "info",
    title: "Update Available",
    message: "A new version is available. Would you like to download it now?",
    buttons: ["Yes", "No"],
    defaultId: 0
  }).then((result) => {
    if (result.response === 0) {
      electronUpdater.autoUpdater.downloadUpdate();
    }
  });
});
electronUpdater.autoUpdater.on("update-not-available", () => {
  console.log("Update not available");
});
electronUpdater.autoUpdater.on("error", (err) => {
  console.log("Error in auto-updater:", err);
  electron.dialog.showErrorBox("Update Error", "Error checking for updates: " + err.message);
});
electronUpdater.autoUpdater.on("download-progress", (progressObj) => {
  console.log("Download progress:", progressObj);
});
electronUpdater.autoUpdater.on("update-downloaded", (info) => {
  console.log("Update downloaded:", info);
  electron.dialog.showMessageBox({
    type: "info",
    title: "Update Ready",
    message: "Update downloaded. The application will restart to install the update.",
    buttons: ["Restart Now", "Later"],
    defaultId: 0
  }).then((result) => {
    if (result.response === 0) {
      electronUpdater.autoUpdater.quitAndInstall();
    }
  });
});
function startBackend() {
  const backendPath = utils.is.dev ? path.join(process.cwd(), "backend", "server.js") : path.join(__dirname, "..", "backend", "server.js");
  console.log("Starting backend at:", backendPath);
  backendProcess = child_process.spawn("node", [backendPath], {
    stdio: "inherit",
    shell: process.platform === "win32"
    // For Windows compatibility
  });
  backendProcess.on("close", (code) => {
    console.log(`Backend process exited with code ${code}`);
  });
  backendProcess.on("error", (error) => {
    console.error("Backend process error:", error);
  });
}
function createWindow() {
  const mainWindow = new electron.BrowserWindow({
    width: 900,
    height: 670,
    show: false,
    autoHideMenuBar: true,
    ...process.platform === "linux" ? { icon } : {},
    webPreferences: {
      preload: path.join(__dirname, "../preload/index.js"),
      sandbox: false
    }
  });
  mainWindow.on("ready-to-show", () => {
    mainWindow.show();
  });
  mainWindow.webContents.setWindowOpenHandler((details) => {
    electron.shell.openExternal(details.url);
    return { action: "deny" };
  });
  electron.ipcMain.handle("print-receipt", async (event) => {
    const win = electron.BrowserWindow.fromWebContents(event.sender);
    if (win) {
      return new Promise((resolve, reject) => {
        win.webContents.print(
          {
            silent: true,
            printBackground: true,
            pageSize: "A4"
            // Print on A4 paper
          },
          (success, errorType) => {
            if (!success) reject(errorType);
            else resolve("printed");
          }
        );
      });
    }
    return Promise.reject("No window found");
  });
  electron.ipcMain.handle("list-printers", async (event) => {
    const win = electron.BrowserWindow.fromWebContents(event.sender);
    if (win) {
      console.log("webContents methods:", Object.keys(win.webContents));
      return win.webContents.getPrinters();
    }
    return [];
  });
  electron.ipcMain.handle("print-receipt-content", async (_, html) => {
    return new Promise((resolve, reject) => {
      const printWindow = new electron.BrowserWindow({
        width: 800,
        height: 1120,
        // A4 aspect ratio
        show: false,
        webPreferences: {
          sandbox: false
        }
      });
      printWindow.loadURL("data:text/html;charset=utf-8," + encodeURIComponent(`
        <html>
          <head>
            <style>
              @media print {
                body { margin: 0; }
              }
            </style>
          </head>
          <body>${html}</body>
        </html>
      `));
      printWindow.webContents.on("did-finish-load", () => {
        setTimeout(() => {
          printWindow.webContents.print({
            silent: true,
            printBackground: true,
            pageSize: "A4"
          }, (success, errorType) => {
            setTimeout(() => {
              printWindow.close();
            }, 3e3);
            if (!success) reject(errorType);
            else resolve("printed");
          });
        }, 500);
      });
    });
  });
  if (utils.is.dev && process.env["ELECTRON_RENDERER_URL"]) {
    mainWindow.loadURL(process.env["ELECTRON_RENDERER_URL"]);
  } else {
    mainWindow.loadFile(path.join(__dirname, "../renderer/index.html"));
  }
}
electron.app.whenReady().then(() => {
  utils.electronApp.setAppUserModelId("com.electron");
  electron.app.on("browser-window-created", (_, window) => {
    utils.optimizer.watchWindowShortcuts(window);
  });
  electron.ipcMain.on("ping", () => console.log("pong"));
  electron.ipcMain.handle("check-for-updates", async () => {
    try {
      const result = await electronUpdater.autoUpdater.checkForUpdates();
      return { success: true, result };
    } catch (error) {
      console.error("Error checking for updates:", error);
      return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
  });
  electron.ipcMain.handle("download-update", async () => {
    try {
      await electronUpdater.autoUpdater.downloadUpdate();
      return { success: true };
    } catch (error) {
      console.error("Error downloading update:", error);
      return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
  });
  electron.ipcMain.handle("install-update", () => {
    electronUpdater.autoUpdater.quitAndInstall();
    return { success: true };
  });
  electron.ipcMain.handle("get-app-version", () => {
    return electron.app.getVersion();
  });
  startBackend();
  createWindow();
  if (!utils.is.dev) {
    setTimeout(() => {
      electronUpdater.autoUpdater.checkForUpdates();
    }, 3e3);
  }
  electron.app.on("activate", function() {
    if (electron.BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
electron.app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    electron.app.quit();
  }
});

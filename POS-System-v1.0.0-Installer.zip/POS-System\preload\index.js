"use strict";
const electron = require("electron");
const preload = require("@electron-toolkit/preload");
const api = {
  printReceipt: () => electron.ipcRenderer.invoke("print-receipt"),
  listPrinters: () => electron.ipcRenderer.invoke("list-printers"),
  printReceiptContent: (html) => electron.ipcRenderer.invoke("print-receipt-content", html),
  // Update APIs
  checkForUpdates: () => electron.ipcRenderer.invoke("check-for-updates"),
  downloadUpdate: () => electron.ipcRenderer.invoke("download-update"),
  installUpdate: () => electron.ipcRenderer.invoke("install-update"),
  getAppVersion: () => electron.ipcRenderer.invoke("get-app-version")
};
if (process.contextIsolated) {
  try {
    electron.contextBridge.exposeInMainWorld("electron", preload.electronAPI);
    electron.contextBridge.exposeInMainWorld("api", api);
  } catch (error) {
    console.error(error);
  }
} else {
  window.electron = preload.electronAPI;
  window.api = api;
}

POS System v1.0.0
=================

Installation Instructions:
1. Run install.bat as Administrator
2. The application will be installed to C:\Program Files\POS-System
3. A desktop shortcut will be created automatically

System Requirements:
- Windows 10 or later
- Node.js runtime (included)
- Internet connection for database access

Default Login:
Owner: John Doe
PIN: 5222

For support, please contact your system administrator.
